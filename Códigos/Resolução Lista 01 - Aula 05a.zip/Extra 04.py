dinheiro = float(input("Digite a quantidade de dinheiro na carteira: "))
if dinheiro >=10:
    print ("Você deveria ir ao cinema. ")
else:
    print ("Você deveria ficar em casa assistindo TV.")