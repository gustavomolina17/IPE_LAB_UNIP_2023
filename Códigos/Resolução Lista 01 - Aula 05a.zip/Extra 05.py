peso = float (input("Digite seu peso: "))
altura = float (input("Digite sua altura: "))
imc = peso/(altura*altura)
if imc <=18.5:
    print (imc,"abaixo do peso")
elif imc <25:
    print (imc,"peso normal")
elif imc <30:
    print (imc,"sobrepeso")
elif imc <35:
    print (imc,"obeso leve")
elif imc <40:
    print (imc,"obeso moderado")
else:
    print(imc,"obeso mórbido")