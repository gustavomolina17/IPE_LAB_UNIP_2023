x = int(input("Digite um valor para x: "))
while (x != -999):
    r = x * 3
    print ("O triplo do valor digitado é:", r)
    x = int(input("Digite um valor para x: "))
