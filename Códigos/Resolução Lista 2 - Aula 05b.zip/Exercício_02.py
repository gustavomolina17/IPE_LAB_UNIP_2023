contador_f = 0
contador_m = 0
sexo = input("Digite o Sexo (f/m): ")

while (sexo != 'fim'):
    if (sexo == 'f'):
        contador_f += 1
    elif (sexo == 'm'):
        contador_m += 1
    sexo = input("Digite o Sexo: ")
print ("Pessoas do Sexo Feminino:", contador_f)
print ("Pessoas do Sexo Masculino:", contador_m)
