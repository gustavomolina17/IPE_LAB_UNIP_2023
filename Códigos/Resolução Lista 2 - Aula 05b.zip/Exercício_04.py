anterior = 0
proximo = 0
cont = 0 
if proximo==0:
    print(proximo)
    proximo = proximo+1
while(cont != 15):
  print(proximo)
  proximo = proximo + anterior
  anterior = proximo - anterior
  cont = cont +1
    